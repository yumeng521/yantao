<template>
    <div class="header">
        <p class="myd">我的</p>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped lang="styl">
.header{
    position: fixed;
    left: 0;
    top: 0;
    width:100%;
    height: 44px;
    background: #FDD003;
    .myd{
        width:100%;
        height: 30px;
        line-height:30px;
        font-size: 22px;
        color: #000000;
        text-align:center
    }
}
</style>

